<?php
/* Template Name: Inicio
*/

get_header(); ?>
<div class="main-container ">
    <div class="content-home">
    <?php echo do_shortcode('[smartslider3 slider="2"]') ?>
    <div class="grid cx">
    <section class="estrecho grid cx">
        <div id="gallery">
                    <a class="link" href="/nosotros" style="background:url(/wp-content/uploads/2021/03/celeste.jpg)">
                        <div>LOREM IPSUM</div>
                    </a> 
                    <a class="link" href="/areas-de-investigacion" style="background:url(/wp-content/uploads/2021/03/gris.jpg)">
                    <div>LOREM IPSUM</div>

                    </a> 
                    <a class="link" href="/politica-rsu" style="background:url(/wp-content/uploads/2021/03/grisc.jpg)">
                    <div>LOREM IPSUM</div>

                    </a> 
                    <a class="link" href="/noticias-eventos" style="background:url(/wp-content/uploads/2021/03/grisc.jpg)">
                    <div>LOREM IPSUM</div>

                    </a> 
                    <a class="link" href="/noticias-eventos" style="background:url(/wp-content/uploads/2021/03/celeste.jpg)">
                    <div>LOREM IPSUM</div>
                    </a> 
                    <a class="link" href="/noticias-eventos" style="background:url(/wp-content/uploads/2021/03/gris.jpg)">
                    <div>LOREM IPSUM</div>
                    </a> 
                </div>
        </section>
        </div>
        <section>
        <div class="w100 tac">
            <h2 class="title"><?php _e('ÚLTIMAS NOTICIAS', 'inotheme') ?></h2>
            
        </div>
        <div class="noticias grid cx">
        <?php	
                $args = array(
                    'post_type' => 'noticias-post',
                    'posts_per_page' => '3', 

                );
                $query = new WP_Query( $args );
                
                ?>
                <?php if ( $query->have_posts() ) : ?>
                            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                                <div class="noticia grid cx" >
                                
                                    <div class="image grid">
                                        <img src="<?php echo ipq_get_theme_image_url( get_post_thumbnail_id(), array( 450, 350, true ) ); ?>"
                                            alt="<?php echo get_the_title();?>">
                                    </div>  
                                    <div class="description grid">
                                    <h3><?php echo get_the_title();?></h3>
                                    <p><?php echo get_the_excerpt() ?></p>
                                    <div class="w100 tar">
                                        <a href="<?php the_permalink(); ?>"><?php _e('VER NOTICIA', 'inotheme') ?></a>
                                    </div>
                                    </div>
                                </div>
                <?php endwhile;?>            
        <?php endif; ?>
        </div>
        </section>
        <section class="w100 grid cx">
            <div class="w100 tac">
                <h2 class="title"><?php _e('SEMINARIOS Y EVENTOS', 'inotheme') ?></h2>
            </div>

            <div class="eventos estrecho grid cx">
        <?php	
                $args = array(
                    'post_type' => 'eventos-post',
                    'posts_per_page' => '3', 

                );
                $query = new WP_Query( $args );
                
                ?>
                <?php if ( $query->have_posts() ) : ?>
                            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                                <div class="evento grid cx" >
                                
                                    <div class="image grid">
                                        <img src="<?php echo ipq_get_theme_image_url( get_post_thumbnail_id(), array( 450, 350, true ) ); ?>"
                                            alt="<?php echo get_the_title();?>">
                                    </div>  
                                    <div class="description grid">
                                    <h3><?php echo get_the_title();?></h3>
                                    <p><?php echo get_the_excerpt() ?></p>
                                    <a href="<?php the_permalink(); ?>"><?php _e('VER MÁS', 'inotheme') ?></a>

                                    </div>
                                </div>
                <?php endwhile;?>            
        <?php endif; ?>
        </div>
        </section>
        <section>
            <div class="w100 tac">
                <h2 class="title"><?php _e('BLOG', 'inotheme') ?></h2>
            </div>
            <div class="blog grid cx">
        <?php	
                $args = array(
                    'posts_per_page' => '3', 

                );
                $query = new WP_Query( $args );
                
                ?>
                <?php if ( $query->have_posts() ) : ?>
                            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                                <div class="entrada grid cx" >
                                
                                    <div class="image grid">
                                        <img src="<?php echo ipq_get_theme_image_url( get_post_thumbnail_id(), array( 450, 350, true ) ); ?>"
                                            alt="<?php echo get_the_title();?>">
                                    </div>  
                                    <div class="description grid">
                                    <h3><?php echo get_the_title();?></h3>
                                    <p><?php echo get_the_excerpt() ?></p>
                                    <div class="w100 tar">
                                        <a href="<?php the_permalink(); ?>"><?php _e('VER MÁS', 'inotheme') ?></a>
                                    </div>
                                    </div>
                                </div>
                <?php endwhile;?>            
        <?php endif; ?>
        </div>
        </section>
        <section class="grid cx">
            <div class="w100 tac">
                <h2 class="title"><?php _e('NUESTROS ALIADOS', 'inotheme') ?></h2>
            </div>
            <div class="aliados estrecho grid cx">
        <?php	
                $args = array(
                    'posts_per_page' => '3', 
                    'post_type' => 'aliados-post',

                );
                $query = new WP_Query( $args );
                
                ?>
                <?php if ( $query->have_posts() ) : ?>
                            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                                <div class="aliado grid cy" >
                                
                                        <img src="<?php echo ipq_get_theme_image_url( get_post_thumbnail_id(), array( 250, 120, false ) ); ?>"
                                            alt="<?php echo get_the_title();?>">
                           
                                </div>
                <?php endwhile;?>            
        <?php endif; ?>
        </div>
        </section>
    </div>
    <?php get_footer(); ?>